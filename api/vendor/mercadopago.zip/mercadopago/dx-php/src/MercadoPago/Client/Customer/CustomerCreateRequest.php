<?php

namespace MercadoPago\Client\Customer;

/** Customer Create Request class. */
class CustomerCreateRequest
{
    /** Customer email. */
    public string $email;
}
