<?php

namespace MercadoPago\Client\Point;

/** PointDeviceOperatingModeRequest class. */
class PointDeviceOperatingModeRequest
{
    /** Operating mode. */
    public string $operating_mode;
}
