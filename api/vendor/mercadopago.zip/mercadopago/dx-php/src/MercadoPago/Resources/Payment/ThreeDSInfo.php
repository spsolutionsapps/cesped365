<?php

namespace MercadoPago\Resources\Payment;

/** ThreeDSInfo class. */
class ThreeDSInfo
{
    /** External resource url. */
    public ?string $external_resource_url;

    /** Creq. */
    public ?string $creq;
}
