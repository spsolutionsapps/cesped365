<?php

namespace MercadoPago\Resources\Preference;

/** Back URLs class. */
class BackUrls extends Urls
{
}
