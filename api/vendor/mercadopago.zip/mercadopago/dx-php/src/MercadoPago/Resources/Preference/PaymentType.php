<?php

namespace MercadoPago\Resources\Preference;

/** PaymentType class. */
class PaymentType
{
    /** Payment type ID. */
    public ?string $id;
}
